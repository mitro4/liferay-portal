﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","af",{title:"UI kleur keuse",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Voordefinieerte kleur keuses",config:"Voeg hierdie in jou config.js lêr in"});
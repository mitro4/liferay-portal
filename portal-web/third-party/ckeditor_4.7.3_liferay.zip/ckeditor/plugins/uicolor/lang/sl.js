﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","sl",{title:"UI Izbiralec Barve",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Vnaprej določeni barvni kompleti",config:"Prilepite ta niz v vašo config.js datoteko"});
﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","hr",{title:"Informacije elementa",dialogName:"Naziv prozora za dijalog",tabName:"Naziv kartice",elementId:"ID elementa",elementType:"Vrsta elementa"});